export class GetAllCustomersQuery {}
